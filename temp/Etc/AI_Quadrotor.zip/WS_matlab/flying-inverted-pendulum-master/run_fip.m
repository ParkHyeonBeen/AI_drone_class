run('fip_init.m');
run('fip_RL.m');
run('fip_plot.m');