clear;clc;close all

global n t

load('Final_dynamics_Eqn.mat','inertia_matrix','inv_inertia_matrix','cori','grav');

syms m1 m2 m3 m4 l1 l2 l3 g % link parameters
syms Alpha Theta1 Theta2 D % symbolic variables
syms Alpha_1dot Theta1_1dot Theta2_1dot D_1dot % symbolic variables
syms Alpha_2dot Theta1_2dot Theta2_2dot D_2dot % symbolic variables
syms a_0(t) theta1_0(t) theta2_0(t) d_0(t) % time variables
syms a_1dot(t) theta1_1dot(t) theta2_1dot(t) d_1dot(t) % time variables
syms a_2dot(t) theta1_2dot(t) theta2_2dot(t) d_2dot(t) % time variables

syms alpha_dot2 theta1_dot2 theta2_dot2 dist_dot2

L1 = 0.5;
L2 = 1;
L3 = 0.8;

M1 = 42.8544999;
M2 = 44.77501;
M3 = 35.5539307;
M4 = 31.5668538;

coe_grav = 9.81;

n = 384; % Sampling ��  t���� ����� �ǵ���
t = 64; % ���� ��Ÿ��     ó���� �˳��ϰ� ���� ��, tf ������� ���� ��, ���� �Է�
step = 19; % ���� ��

inertia_matrix = subs(inertia_matrix,l1,L1);
inertia_matrix = subs(inertia_matrix,l2,L2);
inertia_matrix = subs(inertia_matrix,l3,L3);

inertia_matrix = subs(inertia_matrix,m1,M1);
inertia_matrix = subs(inertia_matrix,m2,M2);
inertia_matrix = subs(inertia_matrix,m3,M3);
inertia_matrix = subs(inertia_matrix,m4,M4);

cori = subs(cori,l1,L1);
cori = subs(cori,l2,L2);
cori = subs(cori,l3,L3);

cori = subs(cori,m1,M1);
cori = subs(cori,m2,M2);
cori = subs(cori,m3,M3);
cori = subs(cori,m4,M4);

grav = subs(grav,l1,L1);
grav = subs(grav,l2,L3);
grav = subs(grav,l3,L3);

grav = subs(grav,m1,M1);
grav = subs(grav,m2,M2);
grav = subs(grav,m3,M3);
grav = subs(grav,m4,M4);

grav = subs(grav,g,coe_grav);

%% Trajectory Planning

t_step = zeros(step,1);

Alpha_desire = zeros(n,1);
Theta1_desire = zeros(n,1);
Theta2_desire = zeros(n,1);
Dist_desire = zeros(n,1);

alpha_val_desire = [0 pi pi pi pi 0 0 0 0 0 0 0 0 0 pi pi pi pi 0];
alpha_vel_desire = [pi/6 0 0 0 -pi/6 0 0 0 0 0 0 0 0 pi/6 0 0 0 -pi/6];
alpha_acc_desire = [pi/12 0 0 0 -pi/12 0 0 0 0 0 0 0 0 pi/12 0 0 0 -pi/12];

theta1_val_desire = [pi/2 pi/2 0 0 0 0 25*pi/180 25*pi/180 25*pi/180 25*pi/180 25*pi/180 25*pi/180 ...
    25*pi/180 0 0 0 0 pi/2 pi/2]; %% vel, accel ����, ��/���� * 360 = pi �� �ǵ���
theta1_vel_desire = [0 -pi/4 0 0 0 5*pi/72 0 0 0 0 0 0 -5*pi/72 0 0 0 pi/4 0];
theta1_acc_desire = [0 -pi/4 0 0 0 5*pi/72 0 0 0 0 0 0 -5*pi/72 0 0 0 pi/4 0];

theta2_val_desire = [210*pi/180 210*pi/180 3*pi/2 3*pi/2 3*pi/2 3*pi/2 275*pi/180 275*pi/180 275*pi/180 275*pi/180 275*pi/180 275*pi/180 ...
    275*pi/180 3*pi/2 3*pi/2 3*pi/2 3*pi/2 210*pi/180 210*pi/180];
theta2_vel_desire = [0 pi/6 0 0 0 pi/72 0 0 0 0 0 0 -pi/72 0 0 0 -pi/6 0];
theta2_acc_desire = [0 pi/6 0 0 0 pi/72 0 0 0 0 0 0 -pi/72 0 0 0 -pi/6 0];

dist_val_desire = [0 0 0 0.2 0 0 0 0.35 0.45 0.35 0.45 0.35 0 0 0 0.2 0 0 0];                                 %% vel, accel ����, ���� 0.1m�� �� 0.1
dist_vel_desire = [0 0 0.2 -0.2 0 0 0.35 0.1 -0.1 0.1 -0.1 -0.35 0 0 0.2 -0.2 0 0];
dist_acc_desire = [0 0 0.2 -0.2 0 0 0.35 0.1 -0.1 0.1 -0.1 -0.35 0 0 0.2 -0.2 0 0];

for i =  1:length(t_step) - 1
    
    fprintf('%d ��° ����\n',i);
    
    alpha = zeros(n,1);
    theta1 = zeros(n,1);
    theta2 = zeros(n,1);
    dist = zeros(n,1);
    
    % alpha ��
    if alpha_val_desire(i) == alpha_val_desire(i+1)
        
        alpha = alpha_val_desire(i)*ones(n,1);
        tf_alpha = 0;
        
    else
        
        [tf_alpha,alpha_val] =  traj(alpha_vel_desire(i),alpha_acc_desire(i),alpha_val_desire(i),alpha_val_desire(i+1),t_step(i));  % [t_f,trajectory] = traj(Val_Velocity,Val_Accel,Val_initial,Val_final,t_ini)
        alpha(1:length(alpha_val)) = alpha_val;
        
        fprintf('alpha length = %d\n\n',length(alpha_val));
        
    end
    
    % theta1 ��
    if theta1_val_desire(i) == theta1_val_desire(i+1)
        
        theta1 = theta1_val_desire(i)*ones(n,1);
        tf_theta1 = 0;
        
    else
        
        [tf_theta1,theta1_val] =  traj(theta1_vel_desire(i),theta1_acc_desire(i),theta1_val_desire(i),theta1_val_desire(i+1),t_step(i));  % [t_f,trajectory] = traj(Val_Velocity,Val_Accel,Val_initial,Val_final,t_ini,n)
        theta1(1:length(theta1_val)) = theta1_val;
        
        fprintf('theta1 length = %d\n\n',length(theta1_val));
        
    end
    
    % theta2 ��
    if theta2_val_desire(i) == theta2_val_desire(i+1)
        
        theta2 = theta2_val_desire(i)*ones(n,1);
        tf_theta2 = 0;
        
    else
        
        [tf_theta2,theta2_val] =  traj(theta2_vel_desire(i),theta2_acc_desire(i),theta2_val_desire(i),theta2_val_desire(i+1),t_step(i));  % [t_f,trajectory] = traj(Val_Velocity,Val_Accel,Val_initial,Val_final,t_ini,n)
        theta2(1:length(theta2_val)) = theta2_val;
        
        fprintf('theta2 length = %d\n\n',length(theta2_val));
        
    end
    
    % distance ��
    if dist_val_desire(i) == dist_val_desire(i+1)
        
        dist = dist_val_desire(i)*ones(n,1);
        tf_dist = 0;
        
    else
        
        [tf_dist,dist_val] =  traj(dist_vel_desire(i),dist_acc_desire(i),dist_val_desire(i),dist_val_desire(i+1),t_step(i));  % [t_f,trajectory] = traj(Val_Velocity,Val_Accel,Val_initial,Val_final,t_ini,n)
        dist(1:length(dist_val)) = dist_val;
        
        fprintf('distance length = %d\n\n',length(dist_val));
        
    end
    
    disp('Each tf');
    disp([tf_alpha tf_theta1 tf_theta2 tf_dist]);
    
    tf = max([tf_alpha tf_theta1 tf_theta2 tf_dist]);
    
%     length_abandon = int16(((tf*n/t) - (t_step(i)*n/t))+1);
    length_input_first = int16((t_step(i)*n/t) + 1);
    length_input_last = int16(tf*n/t);
    
    disp('input_first input_last');
    disp([length_input_first length_input_last]);

    alpha(length_input_last+1:n) = [];
    alpha(1:length_input_first - 1) = [];
    theta1(length_input_last+1:n) = [];
    theta1(1:length_input_first - 1) = [];
    theta2(length_input_last+1:n) = [];
    theta2(1:length_input_first - 1) = [];
    dist(length_input_last+1:n) = [];
    dist(1:length_input_first - 1) = [];
    
    disp('Each Length');
    disp([length(alpha) length(theta1) length(theta2) length(dist)]);
   
    Alpha_desire(length_input_first:length_input_last) = alpha;
    Theta1_desire(length_input_first:length_input_last) = theta1;
    Theta2_desire(length_input_first:length_input_last) = theta2;
    Dist_desire(length_input_first:length_input_last) = dist;
    
    input =  180/pi*[alpha theta1 theta2 dist];
    output = 180/pi*[Alpha_desire Theta1_desire Theta2_desire Dist_desire];
    
    t_step(i+1) = tf;
    
    disp('------------------------------------------------------------------');
  
end
% 
% %% Desired Forward Kinematic
% 
% for i = 1:n
% 
% T_ini=[
%     0 0 1 0;
%     0 1 0 0;
%     -1 0 0 0;
%     0 0 0 1;
%     ];
% 
% T01=[
%     1 0 0 0;
%     0 cos(Alpha_desire(i)) sin(Alpha_desire(i)) 0;
%     0 -sin(Alpha_desire(i)) cos(Alpha_desire(i)) 0;
%     0 0 0 1
%     ];
% 
% T12=[
%     cos(Theta1_desire(i)) -sin(Theta1_desire(i)) 0 L1;
%     sin(Theta1_desire(i)) cos(Theta1_desire(i)) 0 0;
%     0 0 1 0;
%     0 0 0 1
%     ];
% 
% T23=[
%     cos(Theta2_desire(i)) -sin(Theta2_desire(i)) 0 L2;
%     sin(Theta2_desire(i)) cos(Theta2_desire(i)) 0 0;
%     0 0 1 0;
%     0 0 0 1
%     ];
% 
% T34=[
%     1 0 0 L3;
%     0 1 0 0;
%     0 0 1 0;
%     0 0 0 1
%     ];
% 
% T4tool=[
%     1 0 0 Dist_desire(i);
%     0 1 0 0;
%     0 0 1 0;
%     0 0 0 1
%     ];
% 
% E_tool = [0 0 0 1]';
% 
% T001 = T_ini*T01*T12*E_tool;
% T002=T_ini*T01*T12*E_tool;
% T003=T_ini*T01*T12*T23*E_tool;
% T004=T_ini*T01*T12*T23*T34*E_tool;
% T00tool=T_ini*T01*T12*T23*T34*T4tool*E_tool;
% 
% disp(T_ini*T01*T12*T23*T34*T4tool);
% 
% rrrrx = T001(1);rrrry = T001(2);rrrrz = T001(3);
% rrrx = T002(1);rrry = T002(2);rrrz = T002(3);
% rrx = T003(1);rry = T003(2);rrz = T003(3);
% rx = T004(1);ry = T004(2);rz = T004(3);
% x = T00tool(1);y = T00tool(2);z = T00tool(3);
% 
% x_p = [0 rrrrx rrrx rrx rx x];
% y_p = [0 rrrry rrry rry ry y];
% z_p = [0 rrrrz rrrz rrz rz z];
% 
% plot3(x_p,y_p,z_p,'-');
% hold on
% plot3(x,y,z,'*');
% hold off
% 
% axis([-2 1 -1.5 1.5 -2.5 1]);
% grid on
% xlabel('X');
% ylabel('Y');
% zlabel('Z');
% view([1 1 1])
% 
% % ȭ�� ���� ����
% if (i >= 100) && (i < 131)
%     view_new = [1 0 0;0 cos(pi/4) -sin(pi/4);0 sin(pi/4) cos(pi/4)]*[cos(-pi/2*(i-100)/50) -sin(-pi/2*(i-100)/50) 0;sin(-pi/2*(i-100)/50) cos(-pi/2*(i-100)/50) 0;0 0 1]*[1 sqrt(2) 0]';
%     view(view_new);
%     axis([-2 1 -1.5 1.5 -2.5 1]);
% elseif i >= 131
%     view([1 0 0]);
% end
% if (i >= 200) && (i<231)
%     view_new1 = [1 0 0;0 cos(pi/4) -sin(pi/4);0 sin(pi/4) cos(pi/4)]*[cos(pi/2*(i-200)/50) -sin(pi/2*(i-200)/50) 0;sin(pi/2*(i-200)/50) cos(pi/2*(i-200)/50) 0;0 0 1]*[1 0 0]';
%     view(view_new1);
% elseif i>= 231
%      view([1 1 1]);
% end
% 
% drawnow
% 
% end
% 
% disp('��ũ�� ���� ���� tf');
% disp(tf);

%% Dynamics

h = t/n;

Alpha_desire_d = zeros(n,1);
Alpha_desire_dd = zeros(n,1);
Theta1_desire_d = zeros(n,1);
Theta1_desire_dd = zeros(n,1);
Theta2_desire_d = zeros(n,1);
Theta2_desire_dd = zeros(n,1);
Dist_desire_d = zeros(n,1);
Dist_desire_dd = zeros(n,1);

for i = 1:n
    
    if i == n
        Alpha_desire_d(i) = Alpha_desire_d(i-1);
        Theta1_desire_d(i) = Theta1_desire_d(i-1);
        Theta2_desire_d(i) = Theta2_desire_d(i-1);
        Dist_desire_d(i) = Dist_desire_d(i-1);
        break
    end
    
    Alpha_desire_d(i) = (Alpha_desire(i+1) - Alpha_desire(i))/h;
    Theta1_desire_d(i) = (Theta1_desire(i+1) - Theta1_desire(i))/h;
    Theta2_desire_d(i) = (Theta2_desire(i+1) - Theta2_desire(i))/h;
    Dist_desire_d(i) = (Dist_desire(i+1) - Dist_desire(i))/h;
    
end

Alpha_desire_d(1) = 0;
Theta1_desire_d(1) = 0;
Theta2_desire_d(1) = 0;
Dist_desire_d(1) = 0;

for i = 1:n
    
    if i == n
        Alpha_desire_dd(i) = Alpha_desire_dd(i-1);
        Theta1_desire_dd(i) = Theta1_desire_dd(i-1);
        Theta2_desire_dd(i) = Theta2_desire_dd(i-1);
        Dist_desire_dd(i) = Dist_desire_dd(i-1);
        break
    end
    
    Alpha_desire_dd(i) = (Alpha_desire_d(i+1) - Alpha_desire_d(i))/h;
    Theta1_desire_dd(i) = (Theta1_desire_d(i+1) - Theta1_desire_d(i))/h;
    Theta2_desire_dd(i) = (Theta2_desire_d(i+1) - Theta2_desire_d(i))/h;
    Dist_desire_dd(i) = (Dist_desire_d(i+1) - Dist_desire_d(i))/h;
end

Alpha_desire_dd(1) = 0;
Theta1_desire_dd(1) = 0;
Theta2_desire_dd(1) = 0;
Dist_desire_dd(1) = 0;

%% SMC

Alpha = zeros(n,1);
Theta1 = zeros(n,1);
Theta2 = zeros(n,1);
Dist = zeros(n,1);
Alpha_d = zeros(n,1);
Theta1_d = zeros(n,1);
Theta2_d = zeros(n,1);
Dist_d = zeros(n,1);
s1 = zeros(n,1);
s2 = zeros(n,1);
s3 = zeros(n,1);
s4 = zeros(n,1);
Gain1 = zeros(n,1);
Gain2 = zeros(n,1);
Gain3 = zeros(n,1);
Gain4 = zeros(n,1);
Torque_Alpha = zeros(n,1);
Torque_Theta1 = zeros(n,1);
Torque_Theta2 = zeros(n,1);
Force_Dist = zeros(n,1);
Alpha_dd_input = zeros(n,1);
Theta1_dd_input = zeros(n,1);
Theta2_dd_input = zeros(n,1);
Dist_dd_input = zeros(n,1);

Alpha(1) = Alpha_desire(1);
Theta1(1) = Theta1_desire(1);
Theta2(1) = Theta2_desire(1);
Dist(1) = Dist_desire(1);

Alpha_d(1) = Alpha_desire_d(1);
Theta1_d(1) = Theta1_desire_d(1);
Theta2_d(1) = Theta2_desire_d(1);
Dist_d(1) = Dist_desire_d(1);

C1 = 5;
C2 = 5;
C3 = 5;
C4 = 2;

K1 = 0.1;
K2 = 0.1;
K3 = 0.1;
K4 = 0.02;

Alpha_input = Alpha(1);
Theta1_input = Theta1(1);
Theta2_input = Theta2(1);
Dist_input = Dist(1);

Alpha_d_input = Alpha_d(1);
Theta1_d_input = Theta1_d(1);
Theta2_d_input = Theta2_d(1);
Dist_d_input = Dist_d(1);

inertia_matrix = subs(inertia_matrix,a_0,Alpha_input);
inertia_matrix = subs(inertia_matrix,theta1_0,Theta1_input);
inertia_matrix = subs(inertia_matrix,theta2_0,Theta2_input);
inertia_matrix = subs(inertia_matrix,d_0,Dist_input);

cori = subs(cori,a_0,Alpha_input);
cori = subs(cori,theta1_0,Theta1_input);
cori = subs(cori,theta2_0,Theta2_input);
cori = subs(cori,d_0,Dist_input);

cori = subs(cori,a_1dot,Alpha_d_input);
cori = subs(cori,theta1_1dot,Theta1_d_input);
cori = subs(cori,theta2_1dot,Theta2_d_input);
cori = subs(cori,d_1dot,Dist_d_input);

grav = subs(grav,theta1_0,Theta1_input);
grav = subs(grav,theta2_0,Theta2_input);
grav = subs(grav,d_0,Dist_input);

inertia_matrix = double(inertia_matrix);
cori = double(cori);
grav = double(grav);


disp('initial inertia_matrix, cori, grav');
disp(inertia_matrix);
disp(cori);
disp(grav);

for i= 1:n
    
    disp('------------------------------------------------------------------');
    fprintf('%d��° ����',i);
    
    Alpha_input = Alpha(i);
    Theta1_input = Theta1(i);
    Theta2_input = Theta2(i);
    Dist_input = Dist(i);
    
    Alpha_d_input = Alpha_desire_d(i);
    Theta1_d_input = Theta1_desire_d(i);
    Theta2_d_input = Theta2_desire_d(i);
    Dist_d_input = Dist_desire_d(i);
    
    disp('Input value');
    disp([Alpha_input Theta1_input Theta2_input Dist_input]);
    disp('Input derivative value');
    disp([Alpha_d_input Theta1_d_input Theta2_d_input Dist_d_input]);
    disp('Desired derivative value');
    disp([Alpha_desire_d(i) Theta1_desire_d(i) Theta2_desire_d(i) Dist_desire_d(i)]);
    disp('Desired 2 derivative value');
    disp([Alpha_desire_dd(i) Theta1_desire_dd(i) Theta2_desire_dd(i) Dist_desire_dd(i)]);
    disp('derivative value');
    disp([Alpha_d(i) Theta1_d(i) Theta2_d(i) Dist_d(i)]);

    Alpha_dd_input(i) = Alpha_desire_dd(i) + C1 * (Alpha_desire_d(i) - Alpha_d(i));
    Theta1_dd_input(i) = Theta1_desire_dd(i) + C2 * (Theta1_desire_d(i) - Theta1_d(i));
    Theta2_dd_input(i) = Theta2_desire_dd(i) + C3 * (Theta2_desire_d(i) - Theta2_d(i));
    Dist_dd_input(i) = Dist_desire_dd(i) + C4 * (Dist_desire_d(i) - Dist_d(i));
    
    if (isnan(Alpha_dd_input(i)) == 1) || (isnan(Theta1_dd_input(i)) == 1) || (isnan(Theta2_dd_input(i)) == 1) || (isnan(Dist_dd_input(i)) == 1) ...
            || (isinf(Alpha_dd_input(i)) == 1) || (isinf(Theta1_dd_input(i)) == 1) || (isinf(Theta2_dd_input(i)) == 1) || (isinf(Dist_dd_input(i)) == 1)
        fprintf('I found Inf or NaN Value at %dth\n\n',i);
        break
    end
    
    input_desire = [Alpha_dd_input(i) Theta1_dd_input(i) Theta2_dd_input(i) Dist_dd_input(i)]';
    
    Actuator = inertia_matrix * input_desire + cori + grav;
    
    disp('input, inertia_matrix, cori, grav');
    disp(input_desire);
    disp(inertia_matrix);
    disp(cori);
    disp(grav);
    
    Output1 = double(Actuator(1));
    Output2 = double(Actuator(2));
    Output3 = double(Actuator(3));
    Output4 = double(Actuator(4));
    
    if (isnan(Output1) == 1) || (isnan(Output2) == 1) || (isnan(Output3) == 1) || (isnan(Output4) == 1) ...
            || (isinf(Output1) == 1) || (isinf(Output2) == 1) || (isinf(Output3) == 1) || (isinf(Output4) == 1)
        fprintf('I found Inf or NaN Value at %dth\n\n',i);
        break
    end
    
    disp('Actuator value');
    disp([Output1 Output2 Output3 Output4]);
   
    disp('Compare desire vs command');
    disp([Alpha_desire(i) Alpha(i) Alpha_desire_d(i) Alpha_d(i)]);
    disp(Alpha_desire(i) - Alpha(i));
    disp(C1*(Alpha_desire(i) - Alpha(i)));
    disp((Alpha_desire_d(i) - Alpha_d(i)));
    disp(C1*(Alpha_desire(i) - Alpha(i)) + (Alpha_desire_d(i) - Alpha_d(i)));
    
    s1(i) = C1*(Alpha_desire(i) - Alpha(i)) + (Alpha_desire_d(i) - Alpha_d(i));
    s2(i) = C2*(Theta1_desire(i) - Theta1(i))+(Theta1_desire_d(i) - Theta1_d(i)); % s = c*e + e_d
    s3(i) = C3*(Theta2_desire(i) - Theta2(i))+(Theta2_desire_d(i) - Theta2_d(i));
    s4(i) = C4*(Dist_desire(i) - Dist(i))+(Dist_desire_d(i) - Dist_d(i));
    
    disp('S value');
    disp([s1(i) s2(i) s3(i) s4(i)]); %s2 s3 s4
   
    Gain1(i) = +K1 * sign(s1(i));
    Gain2(i) = +K2 * sign(s2(i));
    Gain3(i) = +K3 * sign(s3(i)); 
    Gain4(i) = +K4 * sign(s4(i));
    
    disp('Gain value');
    disp([Gain1(i) Gain2(i) Gain3(i) Gain4(i)]);
    
    Torque_Alpha(i) = Output1 + Gain1(i);
    Torque_Theta1(i) = Output2 + Gain2(i);
    Torque_Theta2(i) = Output3 + Gain3(i);
    Force_Dist(i) = Output4 + Gain4(i);
    
    disp('Torque_Alpha Torque_theta1 Torque_theta2 Force_Dist');
    disp([Torque_Alpha(i) Torque_Theta1(i) Torque_Theta2(i) Force_Dist(i)]);
    
    output_desire = [Torque_Alpha(i) Torque_Theta1(i) Torque_Theta2(i) Force_Dist(i)]';
    
    inertia_matrix = double(inertia_matrix);
    cori = double(cori);
    grav = double(grav);
    
    disp('output, inertia_matrix, cori, grav');
    disp(output_desire);
    disp(inertia_matrix);
    disp(inv(inertia_matrix));
    disp(cori);
    disp(grav);
    
    Control = (inertia_matrix)\(output_desire - cori - grav);
    disp('Control matrix');
    disp(Control);
    
    disp('inertia_matrix');
    disp(inertia_matrix);
    
    disp('W term');
    disp(output_desire - cori - grav);
    
    if (isnan(Control(1)) == 1) || (isnan(Control(2)) == 1) || (isnan(Control(3)) == 1) || (isnan(Control(4)) == 1) ...
            || (isinf(Control(1)) == 1) || (isinf(Control(2)) == 1) || (isinf(Control(3)) == 1) || (isinf(Control(4)) == 1)
        fprintf('I found Inf or NaN Value at %dth\n\n',i);
        break
    end
    
    Alpha_dd(i) = Control(1);
    Theta1_dd(i) = Control(2);
    Theta2_dd(i) = Control(3);
    Dist_dd(i) = Control(4);
    
    disp('Control');
    disp([Alpha_dd(i) Theta1_dd(i) Theta2_dd(i) Dist_dd(i)]);
    
    Alpha_d(i+1)=Alpha_d(i)+h*Alpha_dd(i);
    Alpha(i+1)=Alpha(i)+h*Alpha_d(i+1);
    
    Theta1_d(i+1)=Theta1_d(i)+h*Theta1_dd(i);
    Theta1(i+1)=Theta1(i)+h*Theta1_d(i+1);
    
    Theta2_d(i+1)=Theta2_d(i)+h*Theta2_dd(i);
    Theta2(i+1)=Theta2(i)+h*Theta2_d(i+1);
    
    Dist_d(i+1)=Dist_d(i)+h*double(Dist_dd(i));
    Dist(i+1)=Dist(i)+h*Dist_d(i+1);
    
    Error1_Alpha = zeros(n,1);
    Error1_Theta1 = zeros(n,1);
    Error1_Theta2 = zeros(n,1);
    Error1_Dist = zeros(n,1);
    
    Error2_Alpha = zeros(n,1);
    Error2_Theta1 = zeros(n,1);
    Error2_Theta2 = zeros(n,1);
    Error2_Dist = zeros(n,1);

    Error1_Alpha(i) = Alpha(i) - Alpha_desire(i);
    Error2_Alpha(i) = Alpha_d(i) - Alpha_desire_d(i);
    Error1_Theta1(i) = Theta1(i) - Theta1_desire(i);
    Error2_Theta1(i) = Theta1_d(i) - Theta1_desire_d(i);
    Error1_Theta2(i) = Theta2(i) - Theta2_desire(i);
    Error2_Theta2(i) = Theta2_d(i) - Theta2_desire_d(i);
    Error1_Dist(i) = Dist(i) - Dist_desire(i);
    Error2_Dist(i) = Dist_d(i) - Dist_desire_d(i);
end

%% Final Result

figure(1)
plot(Alpha_desire);
title('Alpha');
hold on
plot(Alpha);
plot(s1);
grid
legend({'Desired Alpha','Alpha','s1'},'Location','southwest');

figure(2)
plot(Theta1_desire);
title('Theta1');
hold on
plot(Theta1);
plot(s2);
grid
legend({'Desired Theta1','Theta1','s2'},'Location','southwest');

figure(3)
plot(Theta2_desire);
title('Theta2');
hold on
plot(Theta2);
plot(s3);
grid
legend({'Desired Theta2','Theta2','s3'},'Location','southwest');

figure(4)
plot(Dist_desire);
title('Dist');
hold on
plot(Dist);
plot(s4);
grid
legend({'Desired Dist','Dist','s4'},'Location','southwest');

figure(5)
plot(Torque_Alpha);
title('Torque Alpha');
grid

figure(6)
plot(Torque_Theta1);
title('Torque Theta1');
grid

figure(7)
plot(Torque_Theta2);
title('Torque Theta2');
grid


figure(8)
plot(Force_Dist);
title('Force Dist');
grid
% 
% figure(9)
% title('Alpha - Alpha_dot');
% plot(Error1_Alpha,Error2_Alpha);
% grid
% 
% figure(10)
% title('Theta1 - Theta1_dot');
% plot(Error1_Theta1,Error2_Theta1);
% grid
% 
% figure(11)
% title('Theta2 - Theta2_dot');
% plot(Error1_Theta2,Error2_Theta2);
% grid
% 
% figure(12)
% title('Dist - Dist_dot');
% plot(Error1_Dist,Error2_Dist);
% grid

%% Desired Forward Kinematic

for i = 1:n

T_ini=[
    0 0 1 0;
    0 1 0 0;
    -1 0 0 0;
    0 0 0 1;
    ];

T01=[
    1 0 0 0;
    0 cos(Alpha(i)) sin(Alpha(i)) 0;
    0 -sin(Alpha(i)) cos(Alpha(i)) 0;
    0 0 0 1
    ];

T12=[
    cos(Theta1(i)) -sin(Theta1(i)) 0 L1;
    sin(Theta1(i)) cos(Theta1(i)) 0 0;
    0 0 1 0;
    0 0 0 1
    ];

T23=[
    cos(Theta2(i)) -sin(Theta2(i)) 0 L2;
    sin(Theta2(i)) cos(Theta2(i)) 0 0;
    0 0 1 0;
    0 0 0 1
    ];

T34=[
    1 0 0 L3;
    0 1 0 0;
    0 0 1 0;
    0 0 0 1
    ];

T4tool=[
    1 0 0 Dist(i);
    0 1 0 0;
    0 0 1 0;
    0 0 0 1
    ];

E_tool = [0 0 0 1]';

T001 = T_ini*T01*T12*E_tool;
T002=T_ini*T01*T12*E_tool;
T003=T_ini*T01*T12*T23*E_tool;
T004=T_ini*T01*T12*T23*T34*E_tool;
T00tool=T_ini*T01*T12*T23*T34*T4tool*E_tool;

disp(T_ini*T01*T12*T23*T34*T4tool);

rrrrx = T001(1);rrrry = T001(2);rrrrz = T001(3);
rrrx = T002(1);rrry = T002(2);rrrz = T002(3);
rrx = T003(1);rry = T003(2);rrz = T003(3);
rx = T004(1);ry = T004(2);rz = T004(3);
x = T00tool(1);y = T00tool(2);z = T00tool(3);

x_p = [0 rrrrx rrrx rrx rx x];
y_p = [0 rrrry rrry rry ry y];
z_p = [0 rrrrz rrrz rrz rz z];

figure(13)
plot3(x_p,y_p,z_p,'-');
hold on
plot3(x,y,z,'*');
hold off

axis([-2 1 -1.5 1.5 -2.5 1]);
grid on
xlabel('X');
ylabel('Y');
zlabel('Z');
view([1 1 1])

% ȭ�� ���� ����
if (i >= 100) && (i < 131)
    view_new = [1 0 0;0 cos(pi/4) -sin(pi/4);0 sin(pi/4) cos(pi/4)]*[cos(-pi/2*(i-100)/50) -sin(-pi/2*(i-100)/50) 0;sin(-pi/2*(i-100)/50) cos(-pi/2*(i-100)/50) 0;0 0 1]*[1 sqrt(2) 0]';
    view(view_new);
    axis([-2 1 -1.5 1.5 -2.5 1]);
elseif i >= 131
    view([1 0 0]);
end
if (i >= 200) && (i<231)
    view_new1 = [1 0 0;0 cos(pi/4) -sin(pi/4);0 sin(pi/4) cos(pi/4)]*[cos(pi/2*(i-200)/50) -sin(pi/2*(i-200)/50) 0;sin(pi/2*(i-200)/50) cos(pi/2*(i-200)/50) 0;0 0 1]*[1 0 0]';
    view(view_new1);
elseif i>= 231
     view([1 1 1]);
end

drawnow

end

%% Timeseries Converter

Alpha_ts = timeseries(Alpha,t/n:t/n:t+t/n);
Theta1_ts = timeseries(Theta1,t/n:t/n:t+t/n);
Theta2_ts = timeseries(Theta2,t/n:t/n:t+t/n);
Dist_ts = timeseries(Dist,t/n:t/n:t+t/n);

Torque_Alpha_ts = timeseries(Torque_Alpha,t/n:t/n:t);
Torque_Theta1_ts = timeseries(Torque_Theta1,t/n:t/n:t);
Torque_Theta2_ts = timeseries(Torque_Theta2,t/n:t/n:t);
Force_Dist_ts = timeseries(Force_Dist,t/n:t/n:t);

%% Trajectory Planning Function

function [t_f,trajectory] = traj(Val_Velocity,Val_Accel,Val_initial,Val_final,t_ini)

global n t

t1 = t_ini + Val_Velocity/Val_Accel;
t2 = t1 + (Val_final - Val_initial)/Val_Velocity - Val_Velocity/Val_Accel;
t_f = t1 - t_ini + t2;

if t2 < t1
    disp('check your velocity, accel');
    return
end

n_fcn = int16(n/t*(t_f - t_ini));

h = (t_f - t_ini)/double(n_fcn);

trajectory = zeros(n_fcn,1);

for i = t_ini:h:t1
    N = int16(i/h) + 1;
    trajectory(N) = (Val_Accel*(i - t_ini)^2)/2 + Val_initial;
end

for i = t1:h:t2
    N = int16(i/h) + 1;
    if (N < 0) || (isinteger(N) == 0) || (isinteger(int16(t1/h)) == 0)
        disp('not int');
        return
    else
    trajectory(N) = trajectory(int16(t1/h)) + Val_Velocity*(i - t1);
    end

end

for i = t2:h:t_f
    N = int16(i/h) + 1;
    trajectory(N) = (-Val_Accel*(i - t_f)^2)/2 + Val_final;

end

trajectory(int16(t_f/h)+1) = [];

disp('   t_ini   t1   t2   t_f');
disp([t_ini t1 t2 t_f]);

end