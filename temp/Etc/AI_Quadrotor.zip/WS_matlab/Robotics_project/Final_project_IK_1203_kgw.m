%%
clear; close; clc

%% Inverse Kinematics

L1=0.5;
L2=1;
L3=0.8;

% [cartesian coordinate] - [1.5 1 2.5]

n_wp=15; % number of waypoints

wp=zeros(n_wp,4);

wp(1, :)=[0 0 3/2*pi 0];

wp1=[-1.5 0.5 -1.5]; init1=[0 2*pi; 0 2*pi; 0 2*pi; 0 0.8]; wp(2, :)=ik(wp1, init1);

wp2=[-1.5 1.5 -1.5]; init2=[wp(2,1) 2*pi; 0 2*pi; 0 2*pi; wp(2,4) 0.8]; wp(3, :)=ik(wp2, init2);

wp3=[-1.5 1.5 -1.3]; init3=[0 2*pi; 0 2*pi; 0 2*pi; 0 0.8]; wp(4, :)=ik(wp3, init3);

wp4=[-1.5 0.5 -1.3]; init4=[0 wp(4,1); 0 2*pi; 0 2*pi; 0 wp(4,4)]; wp(5, :)=ik(wp4, init4);

wp5=[-1.5 0.5 -1.1]; init5=[0 2*pi; 0 2*pi; 0 2*pi; 0 0.8]; wp(6, :)=ik(wp5, init5);

wp6=[-1.5 1.5 -1.1]; init6=[wp(6,1) 2*pi; 0 2*pi; 0 2*pi; wp(6,4) 0.8]; wp(7, :)=ik(wp6, init6);

wp7=[-1.5 1.5 -0.9]; init7=[0 2*pi; 0 2*pi; 0 2*pi; 0 0.8]; wp(8, :)=ik(wp7, init7);

wp8=[-1.5 0.5 -0.9]; init8=[0 wp(8,1); 0 2*pi; 0 2*pi; 0 wp(8,4)]; wp(9, :)=ik(wp8, init8);

wp9=[-1.5 0.5 -0.7]; init9=[0 2*pi; 0 2*pi; 0 2*pi; 0 0.8]; wp(10, :)=ik(wp9, init9);

wp10=[-1.5 1.5 -0.7]; init10=[wp(10,1) 2*pi; 0 2*pi; 0 2*pi; wp(10,4) 0.8]; wp(11, :)=ik(wp10, init10);

wp11=[-1.5 1.5 -0.5]; init11=[0 2*pi; 0 2*pi; 0 2*pi; 0 0.8]; wp(12, :)=ik(wp11, init11);

wp12=[-1.5 0.5 -0.5]; init12=[0 wp(12,1); 0 2*pi; 0 2*pi; 0 wp(12,4)]; wp(13, :)=ik(wp12, init12);

wp13=wp1; init13=[wp(13,1) wp(13,2) wp(13,3) wp(13,4)]; wp(14, :)=ik(wp13, init13); 

wp(n_wp, :)=wp(1, :);

%% N-Point Interpolation

n=10;
step=n/10;
N=14*(n/step)+1; % number of data points
x=zeros(n_wp,1);
a_inv = zeros(n_wp,1);
theta1_inv = zeros(n_wp,1);
theta2_inv = zeros(n_wp,1);
d_inv = zeros(n_wp,1);
for i=1:n_wp
    x(i)=n*(i-1);
    a_inv(i)=wp(i,1);
    theta1_inv(i)=wp(i,2);
    theta2_inv(i)=wp(i,3);
    d_inv(i)=wp(i,4);
end

x_new=[0:step:14*n];

a_inv=interp1(x,a_inv,x_new);
theta1_inv=interp1(x,theta1_inv,x_new);
theta2_inv=interp1(x,theta2_inv,x_new);
d_inv=interp1(x,d_inv,x_new);

%% Forward Kinematic

for i = 1:length(a_inv)
    
    T_ini=[
        0 0 1 0;
        0 1 0 0;
        -1 0 0 0;
        0 0 0 1;
        ];
    
    T01=[
        1 0 0 0;
        0 cos(a_inv(i)) sin(a_inv(i)) 0;
        0 -sin(a_inv(i)) cos(a_inv(i)) 0;
        0 0 0 1
        ];
    
    T12=[
        cos(theta1_inv(i)) -sin(theta1_inv(i)) 0 L1;
        sin(theta1_inv(i)) cos(theta1_inv(i)) 0 0;
        0 0 1 0;
        0 0 0 1
        ];
    
    T23=[
        cos(theta2_inv(i)) -sin(theta2_inv(i)) 0 L2;
        sin(theta2_inv(i)) cos(theta2_inv(i)) 0 0;
        0 0 1 0;
        0 0 0 1
        ];
    
    T34=[
        1 0 0 L3;
        0 1 0 0;
        0 0 1 0;
        0 0 0 1
        ];
    
    T4tool=[
        1 0 0 d_inv(i);
        0 1 0 0;
        0 0 1 0;
        0 0 0 1
        ];
    
    E_tool = [0 0 0 1]';
    
    T001 = T_ini*T01*T12*E_tool;
    T002=T_ini*T01*T12*E_tool;
    T003=T_ini*T01*T12*T23*E_tool;
    T004=T_ini*T01*T12*T23*T34*E_tool;
    T00tool=T_ini*T01*T12*T23*T34*T4tool*E_tool;
    
    disp(T_ini*T01*T12*T23*T34*T4tool);
    
    rrrrx = T001(1);rrrry = T001(2);rrrrz = T001(3);
    rrrx = T002(1);rrry = T002(2);rrrz = T002(3);
    rrx = T003(1);rry = T003(2);rrz = T003(3);
    rx = T004(1);ry = T004(2);rz = T004(3);
    x = T00tool(1);y = T00tool(2);z = T00tool(3);
    
    x_p = [0 rrrrx rrrx rrx rx x];
    y_p = [0 rrrry rrry rry ry y];
    z_p = [0 rrrrz rrrz rrz rz z];
    
    figure(1)
    plot3(x_p,y_p,z_p,'-');
    hold on
    plot3(x,y,z,'*');
    hold off
    
    axis([-3 3 -3 3 -3 1]);
    grid on
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    
    figure(2)
    plot3(x,y,z,'*');
    hold on
    
    axis([-2 1 -1.5 1.5 -2.5 1]);
    grid on
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    
    % figure(2)
    % plot3(x,y,z,'*');
    % hold on
    % plot3(x_p,y_p,z_p,'-');
    % plot3(position1x(i),position1y(i),position1z(i),'o','Color','b','MarkerSize',10);
    % plot3(position2x(i),position2y(i),position2z(i),'o','Color','r','MarkerSize',10);
    %
    % axis([-3 3 -3 3 -3 3]);
    % grid on
    % xlabel('X');
    % ylabel('Y');
    % zlabel('Z');
    % % view([1,0,0])
    
    
    
    drawnow
    
end

%% Inverse Kinematics Solver Function

function F=ik(waypoint, init)

syms a theta1 theta2 d
l1=0.5;
l2=1;
l3=0.8;

vars=[a theta1 theta2 d];

eqn1 = d*(sin(a)*cos(theta1)*sin(theta2) + sin(a)*cos(theta2)*sin(theta1)) + l3*(sin(a)*cos(theta1)*sin(theta2) + sin(a)*cos(theta2)*sin(theta1)) + l2*sin(a)*sin(theta1) - waypoint(1) == 0;
eqn2 = d*(cos(a)*cos(theta1)*sin(theta2) + cos(a)*cos(theta2)*sin(theta1)) + l3*(cos(a)*cos(theta1)*sin(theta2) + cos(a)*cos(theta2)*sin(theta1)) + l2*cos(a)*sin(theta1) - waypoint(2) == 0;
eqn3 = - l1 - d*(cos(theta1)*cos(theta2) - sin(theta1)*sin(theta2)) - l3*(cos(theta1)*cos(theta2) - sin(theta1)*sin(theta2)) - l2*cos(theta1) - waypoint(3) == 0;
eqns=[eqn1 eqn2 eqn3];

result=vpasolve(eqns, vars, init);


F(1)=double(result.a);
F(2)=double(result.theta1);
F(3)=double(result.theta2);
F(4)=double(result.d);

end