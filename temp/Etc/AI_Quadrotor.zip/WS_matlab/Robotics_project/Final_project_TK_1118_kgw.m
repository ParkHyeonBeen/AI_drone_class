%% trajectory planning
clear; close all; clc

%% settings

t_start=0; % starting time
t_end=15.5; % ending time
dt=0.02; % setting dt
n=(t_end-t_start)/dt; % number of time steps
alpha=zeros(1,n); % vector of desired joint variable
theta1=zeros(1,n); % vector of desired joint variable
theta2=zeros(1,n); % vector of desired joint variable
d=zeros(1,n); % vector of desired joint variable
L1 = 1; % length of link 1
L2 = 0.8; % length of link 2
L3 = 0.8; % length of link 3

%% alpha

% 0~2

alpha_initial=0; % initial alpha
alpha_final=pi; % final alpha
t0=t_start; % initial time
tf=2; % final time
ang_vel=pi; % angular velocity
ang_acc=ang_vel/(tf-t0-(alpha_final-alpha_initial)/ang_vel); % angular acceleration

t1=t0+ang_vel/ang_acc;
t2=tf-t1+t0;

for i= t0:dt:t1
    n_new=int16(i/dt)+1;
    alpha(n_new)=(ang_acc*(i-t0)^2)/2+alpha_initial;
end
for i=t1:dt:t2
    n_new=int16(i/dt)+1;
    alpha(n_new)=alpha(int16(t1/dt))+ang_vel*(i-t1);
end
for i=t2:dt:tf
    n_new=int16(i/dt)+1;
    alpha(n_new)=alpha(int16(t2/dt))+ang_vel*(i-t2)-(ang_acc*(i-t2)^2)/2;
end

tf_previous=tf;

% 2~9.5

tf=9.5;
for i=tf_previous: dt: tf
    n_new=int16(i/dt)+1;
    alpha(n_new)=pi;
end

tf_previous=tf;

% 9.5~11.5

alpha_initial=alpha(int16(tf_previous/dt));
alpha_final=0;
t0=tf_previous;
tf=11.5;
ang_vel=-pi;
ang_acc=ang_vel/(tf-t0-(alpha_final-alpha_initial)/ang_vel);

t1=t0+ang_vel/ang_acc;
t2=tf-t1+t0;

for i= t0:dt:t1
    n_new=int16(i/dt)+1;
    alpha(n_new)=(ang_acc*(i-t0)^2)/2+alpha_initial;
end
for i=t1:dt:t2
    n_new=int16(i/dt)+1;
    alpha(n_new)=alpha(int16(t1/dt))+ang_vel*(i-t1);
end
for i=t2:dt:tf
    n_new=int16(i/dt)+1;
    alpha(n_new)=alpha(int16(t2/dt))+ang_vel*(i-t2)-(ang_acc*(i-t2)^2)/2;
end

tf_previous=tf;

% 11.5~15.5

tf=15.5;
for i=tf_previous: dt: tf
    n_new=int16(i/dt)+1;
    alpha(n_new)=0;
end

%% theta1

% 0~2

t0=t_start;
tf=2;
for i=t0: dt: tf
    n_new=int16(i/dt)+1;
    theta1(n_new)=pi/2;
end

tf_previous=tf;

% 2~5.5

theta1_initial=theta1(int16(tf_previous/dt)); % initial theta1
theta1_final=0; % final theta1
t0=tf_previous; % initial time
tf=5.5; % final time
ang_vel=-pi/4; % angular velocity
ang_acc=ang_vel/(tf-t0-(theta1_final-theta1_initial)/ang_vel); % angular acceleration

t1=t0+ang_vel/ang_acc;
t2=tf-t1+t0;

for i= t0:dt:t1
    n_new=int16(i/dt)+1;
    theta1(n_new)=(ang_acc*(i-t0)^2)/2+theta1_initial;
end
for i=t1:dt:t2
    n_new=int16(i/dt)+1;
    theta1(n_new)=theta1(int16(t1/dt))+ang_vel*(i-t1);
end
for i=t2:dt:tf
    n_new=int16(i/dt)+1;
    theta1(n_new)=theta1(int16(t2/dt))+ang_vel*(i-t2)-(ang_acc*(i-t2)^2)/2;
end

tf_previous=tf;

% 5.5~11.5

t0=tf_previous;
tf=11.5;
for i=t0: dt: tf
    n_new=int16(i/dt)+1;
    theta1(n_new)=theta1(int16(t0/dt));
end

tf_previous=tf;

% 11.5~13

theta1_initial=theta1(int16(tf_previous/dt));
theta1_final=25/180*pi;
t0=tf_previous;
tf=13;
ang_vel=pi/8;
ang_acc=ang_vel/(tf-t0-(theta1_final-theta1_initial)/ang_vel);

t1=t0+ang_vel/ang_acc;
t2=tf-t1+t0;

for i= t0:dt:t1
    n_new=int16(i/dt)+1;
    theta1(n_new)=(ang_acc*(i-t0)^2)/2+theta1_initial;
end
for i=t1:dt:t2
    n_new=int16(i/dt)+1;
    theta1(n_new)=theta1(int16(t1/dt))+ang_vel*(i-t1);
end
for i=t2:dt:tf
    n_new=int16(i/dt)+1;
    theta1(n_new)=theta1(int16(t2/dt))+ang_vel*(i-t2)-(ang_acc*(i-t2)^2)/2;
end

tf_previous=tf;

% 13~15.5

t0=tf_previous;
tf=15.5;
for i=t0: dt: tf
    n_new=int16(i/dt)+1;
    theta1(n_new)=theta1(int16(t0/dt));
end

%% theta2

% 0~2

t0=t_start;
tf=2;
for i=t0: dt: tf
    n_new=int16(i/dt)+1;
    theta2(n_new)=(210/180)*pi;
end

tf_previous=tf;

% 2~5.5

theta2_initial=theta2(int16(tf_previous/dt)); % initial theta
theta2_final=(270/180)*pi; % final theta 
t0=tf_previous; % initial time
tf=5.5; % final time
ang_vel=pi/8; % angular velocity
ang_acc=ang_vel/(tf-t0-(theta2_final-theta2_initial)/ang_vel); % angular acceleration

t1=t0+ang_vel/ang_acc;
t2=tf-t1+t0;

for i= t0:dt:t1
    n_new=int16(i/dt)+1;
    theta2(n_new)=(ang_acc*(i-t0)^2)/2+theta2_initial;
end
for i=t1:dt:t2
    n_new=int16(i/dt)+1;
    theta2(n_new)=theta2(int16(t1/dt))+ang_vel*(i-t1);
end
for i=t2:dt:tf
    n_new=int16(i/dt)+1;
    theta2(n_new)=theta2(int16(t2/dt))+ang_vel*(i-t2)-(ang_acc*(i-t2)^2)/2;
end

tf_previous=tf;

% 5.5~11.5

t0=tf_previous;
tf=11.5;
for i=t0: dt: tf
    n_new=int16(i/dt)+1;
    theta2(n_new)=theta2(int16(t0/dt));
end

tf_previous=tf;

% 11.5~13

theta2_initial=theta2(int16(tf_previous/dt));
theta2_final=(275/180)*pi;
t0=tf_previous;
tf=13;
ang_vel=pi/32;
ang_acc=ang_vel/(tf-t0-(theta2_final-theta2_initial)/ang_vel);

t1=t0+ang_vel/ang_acc;
t2=tf-t1+t0;

for i= t0:dt:t1
    n_new=int16(i/dt)+1;
    theta2(n_new)=(ang_acc*(i-t0)^2)/2+theta2_initial;
end
for i=t1:dt:t2
    n_new=int16(i/dt)+1;
    theta2(n_new)=theta2(int16(t1/dt))+ang_vel*(i-t1);
end
for i=t2:dt:tf
    n_new=int16(i/dt)+1;
    theta2(n_new)=theta2(int16(t2/dt))+ang_vel*(i-t2)-(ang_acc*(i-t2)^2)/2;
end

tf_previous=tf;

% 13~15.5

t0=tf_previous;
tf=15.5;
for i=t0: dt: tf
    n_new=int16(i/dt)+1;
    theta2(n_new)=theta2(int16(t0/dt));
end

%% d

% 0~5.5

t0=t_start;
tf=5.5;
for i=t0: dt: tf
    n_new=int16(i/dt)+1;
    d(n_new)=0;
end

tf_previous=tf;

% 5.5~7.5

d_initial=d(int16(tf_previous/dt)); % initial theta
d_final=0.2; % final theta 
t0=tf_previous; % initial time
tf=7.5; % final time
ang_vel=0.15; % angular velocity
ang_acc=ang_vel/(tf-t0-(d_final-d_initial)/ang_vel); % angular acceleration

t1=t0+ang_vel/ang_acc;
t2=tf-t1+t0;

for i= t0:dt:t1
    n_new=int16(i/dt)+1;
    d(n_new)=(ang_acc*(i-t0)^2)/2+d_initial;
end
for i=t1:dt:t2
    n_new=int16(i/dt)+1;
    d(n_new)=d(int16(t1/dt))+ang_vel*(i-t1);
end
for i=t2:dt:tf
    n_new=int16(i/dt)+1;
    d(n_new)=d(int16(t2/dt))+ang_vel*(i-t2)-(ang_acc*(i-t2)^2)/2;
end

tf_previous=tf;

% 7.5~9.5

d_initial=d(int16(tf_previous/dt));
d_final=0;
t0=tf_previous;
tf=9.5;
ang_vel=-0.15;
ang_acc=ang_vel/(tf-t0-(d_final-d_initial)/ang_vel);

t1=t0+ang_vel/ang_acc;
t2=tf-t1+t0;

for i= t0:dt:t1
    n_new=int16(i/dt)+1;
    d(n_new)=(ang_acc*(i-t0)^2)/2+d_initial;
end
for i=t1:dt:t2
    n_new=int16(i/dt)+1;
    d(n_new)=d(int16(t1/dt))+ang_vel*(i-t1);
end
for i=t2:dt:tf
    n_new=int16(i/dt)+1;
    d(n_new)=d(int16(t2/dt))+ang_vel*(i-t2)-(ang_acc*(i-t2)^2)/2;
end

tf_previous=tf;

% 9.5~13

t0=tf_previous;
tf=13;
for i=t0: dt: tf
    n_new=int16(i/dt)+1;
    d(n_new)=d(int16(t0/dt));
end

tf_previous=tf;

% 13~15

d_initial=d(int16(tf_previous/dt));
d_final=0.35;
t0=tf_previous;
tf=15;
ang_vel=0.2;
ang_acc=ang_vel/(tf-t0-(d_final-d_initial)/ang_vel);

t1=t0+ang_vel/ang_acc;
t2=tf-t1+t0;

for i= t0:dt:t1
    n_new=int16(i/dt)+1;
    d(n_new)=(ang_acc*(i-t0)^2)/2+d_initial;
end
for i=t1:dt:t2
    n_new=int16(i/dt)+1;
    d(n_new)=d(int16(t1/dt))+ang_vel*(i-t1);
end
for i=t2:dt:tf
    n_new=int16(i/dt)+1;
    d(n_new)=d(int16(t2/dt))+ang_vel*(i-t2)-(ang_acc*(i-t2)^2)/2;
end

tf_previous=tf;

% 15~15.5

d_initial=d(int16(tf_previous/dt));
d_final=0.45;
t0=tf_previous;
tf=15.5;
ang_vel=0.3;
ang_acc=ang_vel/(tf-t0-(d_final-d_initial)/ang_vel);

t1=t0+ang_vel/ang_acc;
t2=tf-t1+t0;

for i= t0:dt:t1
    n_new=int16(i/dt)+1;
    d(n_new)=(ang_acc*(i-t0)^2)/2+d_initial;
end
for i=t1:dt:t2
    n_new=int16(i/dt)+1;
    d(n_new)=d(int16(t1/dt))+ang_vel*(i-t1);
end
for i=t2:dt:tf
    n_new=int16(i/dt)+1;
    d(n_new)=d(int16(t2/dt))+ang_vel*(i-t2)-(ang_acc*(i-t2)^2)/2;
end

tf_previous=tf;

%% forward kinematics plotting

for i = 1:n

T_ini=[
    0 0 1 0;
    0 1 0 0;
    -1 0 0 0;
    0 0 0 1;
    ];

T01=[
    1 0 0 0;
    0 cos(alpha(i)) -sin(alpha(i)) 0;
    0 sin(alpha(i)) cos(alpha(i)) 0;
    0 0 0 1
    ];

T12=[
    cos(theta1(i)) -sin(theta1(i)) 0 L1;
    sin(theta1(i)) cos(theta1(i)) 0 0;
    0 0 1 0;
    0 0 0 1
    ];

T23=[
    cos(theta2(i)) -sin(theta2(i)) 0 L2;
    sin(theta2(i)) cos(theta2(i)) 0 0;
    0 0 1 0;
    0 0 0 1
    ];

T34=[
    1 0 0 L3;
    0 1 0 0;
    0 0 1 0;
    0 0 0 1
    ];

T4tool=[
    1 0 0 d(i);
    0 1 0 0;
    0 0 1 0;
    0 0 0 1
    ];

E_tool = [0 0 0 1]';

T001 = T_ini*T01*T12*E_tool;
T002=T_ini*T01*T12*E_tool;
T003=T_ini*T01*T12*T23*E_tool;
T004=T_ini*T01*T12*T23*T34*E_tool;
T00tool=T_ini*T01*T12*T23*T34*T4tool*E_tool;

rrrrx = T001(1);rrrry = T001(2);rrrrz = T001(3);
rrrx = T002(1);rrry = T002(2);rrrz = T002(3);
rrx = T003(1);rry = T003(2);rrz = T003(3);
rx = T004(1);ry = T004(2);rz = T004(3);
x = T00tool(1);y = T00tool(2);z = T00tool(3);

x_p = [0 rrrrx rrrx rrx rx x];
y_p = [0 rrrry rrry rry ry y];
z_p = [0 rrrrz rrrz rrz rz z];

plot3(x_p,y_p,z_p,'-');
hold on
plot3(x,y,z,'*');
hold off

axis([-2 1 -1.5 1.5 -2.5 1]);
grid on
xlabel('X');
ylabel('Y');
zlabel('Z');
view([1,0,0])

drawnow

end