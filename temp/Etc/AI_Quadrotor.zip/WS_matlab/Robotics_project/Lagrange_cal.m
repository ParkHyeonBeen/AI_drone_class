clear; clc; close all

syms x y z x0 y0 z0 Mp g real
syms x_dot y_dot z_dot x0_dot y0_dot z0_dot real

R_d = [x0, y0, z0]';
R_p = [x, y, z];
R_rela = [x-x0, y-y0, z-z0];
l = sqrt(sum(R_rela.^2));

phi = atan2((y-y0), (x-x0));
theta = acos((z - z0)/l);

phi_dot = diff(phi, x)*x_dot + diff(phi, x0)*x0_dot + diff(phi, y)*y_dot + diff(phi, y0)*y0_dot;
theta_dot = diff(theta, x)*x_dot + diff(theta, x0)*x0_dot + diff(theta, y)*y_dot + diff(theta, y0)*y0_dot + diff(theta, x)*z_dot + diff(theta, x0)*z0_dot;


% R_p = [
%     x0 + L*cos(phi)*sin(theta);
%     y0 + L*sin(phi)*sin(theta);
%     z0 + L*cos(theta)];

V_d = [x0_dot, y0_dot, z0_dot]';
V_p = [x_dot, y_dot, z_dot]';

% V_p = [
%     x0_dot + L*theta_dot*cos(phi)*cos(theta) - L*phi_dot*sin(phi)*sin(theta);
%     y0_dot + L*theta_dot*cos(theta)*sin(phi) + L*phi_dot*cos(phi)*sin(theta);
%     z0_dot - L*theta_dot*sin(theta)];
W_p = [phi_dot, theta_dot]';

Kp = 0.5*Mp*sum(V_p.^2);
Kr = Mp*l^2*sum(W_p.^2);
K = Kp + Kr;

P = Mp*g*z;

L = K - P;
disp("calculation start")
sol = EulerLagrange(R_p, V_p, L, zeros(3)');
disp(sol)
