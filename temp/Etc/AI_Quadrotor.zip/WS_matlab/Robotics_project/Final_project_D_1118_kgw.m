clear;clc; close all

syms m1 m2 m3 m4 l1 l2 l3 g % link parameters
syms Alpha Theta1 Theta2 D % symbolic variables
syms Alpha_1dot Theta1_1dot Theta2_1dot D_1dot % symbolic variables
syms Alpha_2dot Theta1_2dot Theta2_2dot D_2dot % symbolic variables
syms a_0(t) theta1_0(t) theta2_0(t) d_0(t) % time variables
syms a_1dot(t) theta1_1dot(t) theta2_1dot(t) d_1dot(t) % time variables
syms a_2dot(t) theta1_2dot(t) theta2_2dot(t) d_2dot(t) % time variables

syms alpha_dot2 theta1_dot2 theta2_dot2 dist_dot2

T_ini=[0 0 1 0; 0 1 0 0; -1 0 0 0; 0 0 0 1];

T01=[1 0 0 0; 0 cos(Alpha) -sin(Alpha) 0; 0 sin(Alpha) cos(Alpha) 0; 0 0 0 1];

T12=[cos(Theta1) -sin(Theta1) 0 l1; sin(Theta1) cos(Theta1) 0 0; 0 0 1 0; 0 0 0 1];

T23=[cos(Theta2) -sin(Theta2) 0 l2; sin(Theta2) cos(Theta2) 0 0; 0 0 1 0; 0 0 0 1];

T34=[1 0 0 l3; 0 1 0 0; 0 0 1 0; 0 0 0 1];

T4tool=[1 0 0 D; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    
T0tool=T_ini*T01*T12*T23*T34*T4tool;

x_joint=T0tool(1,4);x_joint=subs(x_joint, Alpha, a_0(t));x_joint=subs(x_joint, Theta1, theta1_0(t));x_joint=subs(x_joint, Theta2, theta2_0(t));
x_joint=subs(x_joint, D, d_0(t));

y_joint=T0tool(2,4);y_joint=subs(y_joint, Alpha, a_0(t));y_joint=subs(y_joint, Theta1, theta1_0(t));y_joint=subs(y_joint, Theta2, theta2_0(t));
y_joint=subs(y_joint, D, d_0(t));

z_joint=T0tool(3,4);z_joint=subs(z_joint, Alpha, a_0(t));z_joint=subs(z_joint, Theta1, theta1_0(t));z_joint=subs(z_joint, Theta2, theta2_0(t));
z_joint=subs(z_joint, D, d_0(t));

vx_joint=diff(x_joint, t);
vy_joint=diff(y_joint, t);
vz_joint=diff(z_joint, t);

%% link 1

z_joint1=subs(z_joint, d_0, 0); z_joint1=subs(z_joint1, l3, 0); z_joint1=subs(z_joint1, l2, 0);

K1=0;
P1=m1*g*z_joint1;
L1=K1-P1;

%% link 2

z_joint2=subs(z_joint, d_0, 0); z_joint2=subs(z_joint2, l3, 0);

vx_joint2=subs(vx_joint, d_0, 0); vx_joint2=subs(vx_joint2, l3, 0);
vy_joint2=subs(vy_joint, d_0, 0); vy_joint2=subs(vy_joint2, l3, 0);
vz_joint2=subs(vz_joint, d_0, 0); vz_joint2=subs(vz_joint2, l3, 0);

K2=0.5*m2*((vx_joint2)^2+(vy_joint2)^2+(vz_joint2)^2);
P2=m2*g*z_joint2;
L2=K2-P2;

%% link 3

z_joint3=subs(z_joint, d_0, 0);

vx_joint3=subs(vx_joint, d_0, 0);
vy_joint3=subs(vy_joint, d_0, 0);
vz_joint3=subs(vz_joint, d_0, 0);

K3=0.5*m3*((vx_joint3)^2+(vy_joint3)^2+(vz_joint3)^2);
P3=m3*g*z_joint3;
L3=K3-P3;

%% end effector

K4=0.5*m4*((vx_joint)^2+(vy_joint)^2+(vz_joint)^2);
P4=m4*g*z_joint;
L4=K4-P4;

%% total

L_total=L1+L2+L3+L4;

a_1dot_temp=diff(a_0, t);
L_t=subs(L_total, a_1dot_temp, a_1dot);
theta1_1dot_temp=diff(theta1_0, t);
L_t=subs(L_t, theta1_1dot_temp, theta1_1dot);
theta2_1dot_temp=diff(theta2_0, t);
L_t=subs(L_t, theta2_1dot_temp, theta2_1dot);
d_1dot_temp=diff(d_0, t);
L_t=subs(L_t, d_1dot_temp, d_1dot);

%% torque 0

torque0_term1=subs(L_t, a_1dot, Alpha_1dot);
torque0_term1=diff(torque0_term1, Alpha_1dot);
torque0_term1=subs(torque0_term1, Alpha_1dot, a_1dot);
torque0_term1=diff(torque0_term1, t);
torque0_term1=subs(torque0_term1, a_1dot_temp, a_1dot);
torque0_term1=subs(torque0_term1, theta1_1dot_temp, theta1_1dot);
torque0_term1=subs(torque0_term1, theta2_1dot_temp, theta2_1dot);
torque0_term1=subs(torque0_term1, d_1dot_temp, d_1dot);
a_2dot_temp=diff(a_1dot, t);
torque0_term1=subs(torque0_term1, a_2dot_temp, a_2dot);
theta1_2dot_temp=diff(theta1_1dot, t);
torque0_term1=subs(torque0_term1, theta1_2dot_temp, theta1_2dot);
theta2_2dot_temp=diff(theta2_1dot, t);
torque0_term1=subs(torque0_term1, theta2_2dot_temp, theta2_2dot);
d_2dot_temp=diff(d_1dot, t);
torque0_term1=subs(torque0_term1, d_2dot_temp, d_2dot);

torque0_term2=subs(L_t, a_0, Alpha);
torque0_term2=diff(torque0_term2, Alpha);
torque0_term2=subs(torque0_term2, Alpha, a_0);

T0=simplify(torque0_term1-torque0_term2);

%% torque 1

torque1_term1=subs(L_t, theta1_1dot, Theta1_1dot);
torque1_term1=diff(torque1_term1, Theta1_1dot);
torque1_term1=subs(torque1_term1, Theta1_1dot, theta1_1dot);
torque1_term1=diff(torque1_term1, t);
torque1_term1=subs(torque1_term1, a_1dot_temp, a_1dot);
torque1_term1=subs(torque1_term1, theta1_1dot_temp, theta1_1dot);
torque1_term1=subs(torque1_term1, theta2_1dot_temp, theta2_1dot);
torque1_term1=subs(torque1_term1, d_1dot_temp, d_1dot);
torque1_term1=subs(torque1_term1, a_2dot_temp, a_2dot);
torque1_term1=subs(torque1_term1, theta1_2dot_temp, theta1_2dot);
torque1_term1=subs(torque1_term1, theta2_2dot_temp, theta2_2dot);
torque1_term1=subs(torque1_term1, d_2dot_temp, d_2dot);

torque1_term2=subs(L_t, theta1_0, Theta1);
torque1_term2=diff(torque1_term2, Theta1);
torque1_term2=subs(torque1_term2, Theta1, theta1_0);

T1=simplify(torque1_term1-torque1_term2);

%% torque 2

torque2_term1=subs(L_t, theta2_1dot, Theta2_1dot);
torque2_term1=diff(torque2_term1, Theta2_1dot);
torque2_term1=subs(torque2_term1, Theta2_1dot, theta2_1dot);
torque2_term1=diff(torque2_term1, t);
torque2_term1=subs(torque2_term1, a_1dot_temp, a_1dot);
torque2_term1=subs(torque2_term1, theta1_1dot_temp, theta1_1dot);
torque2_term1=subs(torque2_term1, theta2_1dot_temp, theta2_1dot);
torque2_term1=subs(torque2_term1, d_1dot_temp, d_1dot);
torque2_term1=subs(torque2_term1, a_2dot_temp, a_2dot);
torque2_term1=subs(torque2_term1, theta1_2dot_temp, theta1_2dot);
torque2_term1=subs(torque2_term1, theta2_2dot_temp, theta2_2dot);
torque2_term1=subs(torque2_term1, d_2dot_temp, d_2dot);

torque2_term2=subs(L_t, theta2_0, Theta2);
torque2_term2=diff(torque2_term2, Theta2);
torque2_term2=subs(torque2_term2, Theta2, theta2_0);

T2=simplify(torque2_term1-torque2_term2);

%% force

force_term1=subs(L_t, d_1dot, D_1dot);
force_term1=diff(force_term1, D_1dot);
force_term1=subs(force_term1, D_1dot, d_1dot);
force_term1=diff(force_term1, t);
force_term1=subs(force_term1, a_1dot_temp, a_1dot);
force_term1=subs(force_term1, theta1_1dot_temp, theta1_1dot);
force_term1=subs(force_term1, theta2_1dot_temp, theta2_1dot);
force_term1=subs(force_term1, d_1dot_temp, d_1dot);
force_term1=subs(force_term1, a_2dot_temp, a_2dot);
force_term1=subs(force_term1, theta1_2dot_temp, theta1_2dot);
force_term1=subs(force_term1, theta2_2dot_temp, theta2_2dot);
force_term1=subs(force_term1, d_2dot_temp, d_2dot);

force_term2=subs(L_t, d_0, D);
force_term2=diff(force_term2, D);
force_term2=subs(force_term2, D, d_0);

F=simplify(force_term1-force_term2);

%%

T0 = subs(T0,a_2dot,alpha_dot2);
T0 = subs(T0,theta1_2dot,theta1_dot2);
T0 = subs(T0,theta2_2dot,theta2_dot2);
T0 = subs(T0,d_2dot,dist_dot2);

T1 = subs(T1,a_2dot,alpha_dot2);
T1 = subs(T1,theta1_2dot,theta1_dot2);
T1 = subs(T1,theta2_2dot,theta2_dot2);
T1 = subs(T1,d_2dot,dist_dot2);

T2 = subs(T2,a_2dot,alpha_dot2);
T2 = subs(T2,theta1_2dot,theta1_dot2);
T2 = subs(T2,theta2_2dot,theta2_dot2);
T2 = subs(T2,d_2dot,dist_dot2);

F = subs(F,a_2dot,alpha_dot2);
F = subs(F,theta1_2dot,theta1_dot2);
F = subs(F,theta2_2dot,theta2_dot2);
F = subs(F,d_2dot,dist_dot2);

eqns = [T0 == 0, T1 == 0, T2 == 0, F == 0];
vars = [alpha_dot2 theta1_dot2 theta2_dot2 dist_dot2];
asdasd = [T0 T1 T2 F];
assumeAlso(vars,'real');
assumeAlso(asdasd,'real');
[inertia_matrix,cori_grav] = equationsToMatrix(eqns,vars);
[grav,cori] = equationsToMatrix(-cori_grav,g);
grav = simplify(grav)*g;
cori = simplify(cori);
coli_grav_spf = collect(simplify(cori_grav),g);
inv_inertia_matrix = inv(inertia_matrix);

disp('Inertia matrix');
disp(inertia_matrix);
disp('Coriolis matrix');
disp(cori);
disp('Gravity matrix');
disp(grav);