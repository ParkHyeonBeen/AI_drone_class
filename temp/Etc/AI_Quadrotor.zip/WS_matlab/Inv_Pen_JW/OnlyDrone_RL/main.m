clc; clear;

run('fip_init.m');
run('fip_RL_SAC.m');
%run('fip_plot.m');