mdl = 'fip_test';
open_system(mdl)

% You can define action and observation here
actionInfo = rlNumericSpec([4 1], 'LowerLimit', [-10+9.81 -10 -10 -10]',...
    'UpperLimit', [10+9.81 10 10 10]');
% action is body frame z-wise acceleration and 3X1 angular velocity vector
actionInfo.Name = 'accl';

observationInfo = rlNumericSpec([9 1]);
observationInfo.Name = 'state';

env = rlSimulinkEnv(mdlsel,[mdl '/RL Agent1'],observationInfo, actionInfo);

% You can define the initial value of many parameters such as states or
% destination of the drone with the Reset Function.
env.ResetFcn = @(in)fipResetFcn(in);

% I set agent of SAC. You can modify it to DDPG, TRPO, PPO, DQN or any
% model you want. But If you change the model, then you have to modify the
% action type and agent options also. Because depending on the algorithm,
% action is differed as discrete or continuous.
% for SAC, following link would be helpful.
% https://kr.mathworks.com/help/reinforcement-learning/ref/rlsacagentoptions.html
% https://kr.mathworks.com/help/reinforcement-learning/ref/rlsacagent.html

opt = rlSACAgentOptions('SampleTime',0.02,...
    'ExperienceBufferLength',2000,...
    'CriticUpdateFrequency',1,...
    'PolicyUpdateFrequency',1,...
    'TargetUpdateFrequency',10);
%opt.EntropyWeightOptions.TargetEntropy = -3;
opt.MiniBatchSize = 128;
opt.DiscountFactor = 0.98;  
agent0 = rlSACAgent(observationInfo,actionInfo,opt);

% You can give the specific training options here
% https://kr.mathworks.com/help/reinforcement-learning/ref/rltrainingoptions.html
trainOpts = rlTrainingOptions('StopOnError',"on",...
    'MaxEpisodes',10000);

trainStats = train(agent0, env, trainOpts);
% After train, you can test the model with 'sim(agent, env)'