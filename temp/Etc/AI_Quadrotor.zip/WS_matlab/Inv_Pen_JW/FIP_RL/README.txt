You can simply run 'main.m' to run the model.
'fip_init.m' file initializes the simulator variables.
'fip_RL.m' file constructs RL model. Now the model is set as SAC.
'fipResetFcn.m' file defines the state or other variables when the model resets.
'fip_test.slx' file is the simulink model.