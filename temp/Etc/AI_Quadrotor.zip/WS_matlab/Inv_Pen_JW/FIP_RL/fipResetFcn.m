function in = fipResetFcn(in)

r = 0.8*0.1*(rand-0.5);
blk = 'fip_test/Inverted pendulum dynamics/Integrator4';
%in = setBlockParameter(in,blk,'InitialCondition',num2str(r));
in = setBlockParameter(in,blk,'InitialCondition','0');

s = 0.8*0.1*(rand-0.5);
blk = 'fip_test/Inverted pendulum dynamics/Integrator6';
%in = setBlockParameter(in,blk,'InitialCondition',num2str(s));
in = setBlockParameter(in,blk,'InitialCondition','0');

rd = 0.8*pi/12*randn;
blk = 'fip_test/Inverted pendulum dynamics/Integrator3';
%in = setBlockParameter(in,blk,'InitialCondition',num2str(rd));
in = setBlockParameter(in,blk,'InitialCondition','0');

sd = 0.8*pi/12*randn;
blk = 'fip_test/Inverted pendulum dynamics/Integrator5';
%in = setBlockParameter(in,blk,'InitialCondition',num2str(sd));
in = setBlockParameter(in,blk,'InitialCondition','0');

att1 = pi/12*rand;
att2 = pi/12*rand;
att3 = pi/12*rand;
%att0 = pi/12*rand(3,1);
att0_str = "[" + num2str(att1) + ";" + num2str(att2) + ";" + num2str(att3) + "]";

blk = 'fip_test/Attitude dynamics/Integrator2';
%in = setBlockParameter(in,blk,'InitialCondition',att0_str);
in = setBlockParameter(in,blk,'InitialCondition','[0; 0; 0]');

xd1 = 3 * randn;
xd2 = 3 * randn;
xd3 = 3 * randn;
xd0_str = "[" + num2str(xd1) + ";" + num2str(xd2) + ";" + num2str(xd3) + "]";

blk = 'fip_test/Translational dynamics/Integrator';
%in = setBlockParameter(in,blk,'InitialCondition',xd0_str);
in = setBlockParameter(in,blk,'InitialCondition','[0; 0; 0]');

x1 = 3 * randn;
x2 = 3 * randn;
x3 = 3 * randn;
x0_str = "[" + num2str(x1) + ";" + num2str(x2) + ";" + num2str(x3) + "]";

blk = 'fip_test/Translational dynamics/Integrator1';
%in = setBlockParameter(in,blk,'InitialCondition',x0_str);
in = setBlockParameter(in,blk,'InitialCondition','[0; 0; 0]');

end